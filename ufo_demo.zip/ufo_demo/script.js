// Just defining variables
var svg = d3.select("svg"),
    margin = {top: 40, right: 20, bottom: 210, left: 40},
    margin2 = {top: 400, right: 20, bottom: 30, left: 40},
    width = +svg.attr("width") - margin.left - margin.right,
    height = +svg.attr("height") - margin.top - margin.bottom,
    height2 = +svg.attr("height") - margin2.top - margin2.bottom;

svg.attr("width", width + margin.left + margin.right)
.attr("height", height + margin.top + margin.bottom);

// Used to parse dates
var parseDate = d3.timeParse("%m/%Y");

// The axis scales
var x = d3.scaleTime().range([0, width]),
    x2 = d3.scaleTime().range([0, width]),
    y = d3.scaleLinear().range([height, 0]),
    y2 = d3.scaleLinear().range([height2, 0]);

var xAxis = d3.axisBottom(x),
    xAxis2 = d3.axisBottom(x2),
    yAxis = d3.axisLeft(y);

var area = d3.area()
    .curve(d3.curveMonotoneX)
    .x(function(d) { return x(d.date); })
    .y0(height)
    .y1(function(d) { return y(d.value); });

var area2 = d3.area()
    .curve(d3.curveMonotoneX)
    .x(function(d) { return x2(d.date); })
    .y0(height2)
    .y1(function(d) { return y2(d.value); });

svg.append("defs").append("clipPath")
    .attr("id", "clip")
  .append("rect")
    .attr("width", width)
    .attr("height", height);

// Focus refers to the larger graph
var focus = svg.append("g")
    .attr("class", "focus")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Context refers to the smaller graph that we perform brushing on
var context = svg.append("g")
    .attr("class", "context")
    .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

d3.csv("clean.csv", function(error, data) {
  
  if (error) throw error;
  

  var brush = d3.brushX()
    .extent([[0, 0], [width, height2]])
    .on("brush end", brushed);
  
  // WHen the data is loaded some clean up must be done
  data.forEach(function(d){
    var a = d.date.split("/")
    d.date = parseDate(a[0] + "/" + a[2]);
    d.value = parseInt(d.value);
  });

  // Set proper domains for axis
  x.domain(d3.extent(data, function(d) { return d.date; }));
  y.domain([0, d3.max(data, function(d) { return d.value; })]);
  x2.domain(x.domain());
  y2.domain(y.domain());
  
  // Load data for focus graph
  focus.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area);
  
  // Load data for context graph
  context.append("path")
    .datum(data)
    .attr("class", "area")
    .attr("d", area2);
  

  focus.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

  focus.append("g")
      .attr("class", "axis axis--y")
      .call(yAxis);

  context.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area2);

  context.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height2 + ")")
      .call(xAxis2);

  context.append("g")
      .attr("class", "brush")
      .call(brush)
      .call(brush.move, x.range());

  // This function deals with changes in brushing
  function brushed() {
    var s = d3.event.selection || x2.range();
    var start = s[0];
		var end = s[s.length - 1] + 1;
    var updatedData = data.slice(start, end);
    
    // These next three lines can change the y-axis during brushing but causes a lot of isses
    // y.domain([ 0, d3.max(updatedData, function(d) { return d.value; }) ]);
    // yAxis = d3.axisLeft(y);
    // svg.select(".axis--y").call(yAxis);

    x.domain(s.map(x2.invert, x2));
    focus.select(".area").attr("d", area);
    focus.select(".axis--x").call(xAxis);
    //focus.selectAll(".bar")
    //  .attr("x", function(d) { return x(d.date); });
        
  }
});